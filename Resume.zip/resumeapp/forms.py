from django import forms
from resumeapp.models import ProfileSection


# class ProfileForm(forms.ModelForm):
#
#     class Meta():
#         model=ProfileSection
#         fields=('__all__')
