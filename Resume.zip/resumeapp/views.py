from django.shortcuts import render
from django.http import HttpResponseRedirect,JsonResponse,HttpResponse
from django.views.generic import ListView,DetailView,TemplateView
from resumeapp.models import ProfileSection,BlogSection,EducationSection,EmploymentSection,ProjectSection,IntroSection,SkillSection,TestimonialSection
from django.core.mail import send_mail,BadHeaderError,EmailMessage
# from resumeapp.forms import ProfileForm
from datetime import date

# Create your views here.


class Home(TemplateView):
    template_name='resumeapp/index.html'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet
        # Getting the ProfileSection here
        context['profilesection']=list(ProfileSection.objects.using('resumeapp').values())
        context['profilesection'][0]['profile_picture']=context['profilesection'][0]['profile_picture'][7:] # Modifying the url here to static folder in root
        context['blogsection']=BlogSection.objects.using('resumeapp').all()
        context['education']=EducationSection.objects.using('resumeapp').all()
        context['employment']=EmploymentSection.objects.using('resumeapp').all()
        context['categories']=ProjectSection.objects.using('resumeapp').values('projectcategory').distinct()
        context['projects']=ProjectSection.objects.using('resumeapp').values()
        context['introduction']=IntroSection.objects.using('resumeapp').values()
        context['skillsets']=SkillSection.objects.using('resumeapp').values()
        context['testimonials']=TestimonialSection.objects.using('resumeapp').values()

        #Code to create list of skills from projectskills
        for item in context['projects']:
            item['projectskills']=item['projectskills'].split(',')

        #Code to calcualte age
        born= context['profilesection'][0]['dob']
        today=date.today()
        context['profilesection'][0]['age']=today.year- born.year - ((today.month, today.day) < (born.month, born.day))

        return context


def SendMail(request):
    """This used configurations in settings.py the email settings to be used
    for sending email"""
    name=request.POST['name']
    email=request.POST['email']
    message=request.POST['message']

    if name and message and email:
        try:
            # send_mail('Mail From '+name, message+"Please contact:"+email,'syedjameer.fromfs@gmail.com',['sydjameer@gmail.com']) # Configure your desired mail here to recieve emails
            html_content='<p>'+message+'</p></br><p>Mail from :'+email+'</p>'
            email=EmailMessage('Mail from {}'.format(name),html_content,email,['sydjameer@gmail.com'])
            email.content_subtype="html"
            email.send()

        except BadHeaderError:
            return HttpResponse('Invalid header found.')
        return JsonResponse('Mail Sent Successfully',safe=False)
    else:
        # In reality we'd use a form class
        # to get proper validation errors.
        return JsonResponse('Make sure all fields are entered and valid.',safe=False)

# def Admin(request):
#     file_form=ProfileForm()
#     return render(request,'resumeapp/sample.html',{'file_form':file_form})
