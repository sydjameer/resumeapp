from django.urls import path
from resumeapp import views
from django.contrib.auth.decorators import login_required

app_name='resume'

urlpatterns = [

path(r'',views.Home.as_view(),name='home'),
path('sendmail',views.SendMail,name='sendmail'),
# path('adminsite',views.Admin,name='adminsite')
]
