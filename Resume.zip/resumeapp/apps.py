from django.apps import AppConfig


class ResumeappConfig(AppConfig):
    name = 'resumeapp'
