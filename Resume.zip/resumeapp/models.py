from django.db import models
from django.contrib.auth.models import User
from datetime import date

# Create your models here.
class ProfileSection(models.Model):
    firstname=models.CharField(max_length=260)
    lastname=models.CharField(max_length=260)
    role1=models.CharField(max_length=260,null=True)
    role2=models.CharField(max_length=260,null=True)
    age=models.IntegerField(null=False)
    telephone_code=models.CharField(max_length=260)
    telephone_no=models.CharField(max_length=260)
    email=models.EmailField(max_length=254)
    address=models.CharField(max_length=260,null=True)
    profile_picture=models.ImageField(upload_to = 'static/resumeapp/img/profile/',blank=True)
    gitHub=models.URLField(max_length=1000,null=True)
    linkeDin=models.URLField(max_length=1000,null=True)
    faceBook=models.URLField(max_length=1000,null=True)
    resume_path=models.FileField(upload_to='static/resumeapp/img/files/',blank=True)
    skypeid=models.CharField(max_length=260,null=True)
    dob=models.DateField(default=date.today)

    def __str__(self):
        return ('{} {}'.format(self.firstname,self.lastname))

class BlogSection(models.Model):
    blog_url=models.URLField(max_length=1000)
    blog_image=models.ImageField(upload_to = 'static/resumeapp/img/blog/',blank=True)
    blog_date=models.DateField(auto_now=False, auto_now_add=False)
    post_name=models.CharField(max_length=500)
    post_content=models.TextField(null=True)

    def __str__(self):
        return (self.post_name)


class EducationSection(models.Model):
    university=models.CharField(max_length=500)
    fromdate=models.CharField(max_length=4)
    todate=models.CharField(max_length=4)
    coursename=models.CharField(max_length=500)

    def __str__(self):
        return (self.university)

class EmploymentSection(models.Model):
    company=models.CharField(max_length=500)
    location=models.CharField(max_length=100)
    fromdate=models.CharField(max_length=20)
    todate=models.CharField(max_length=20)
    designation=models.CharField(max_length=500)

    def __str__(self):
        return (self.company)

class ProjectSection(models.Model):
    projectimage=models.ImageField(upload_to = 'static/resumeapp/img/projects/',blank=True)
    projectimage1=models.ImageField(upload_to = 'static/resumeapp/img/projects/',blank=True)
    projectimage2=models.ImageField(upload_to = 'static/resumeapp/img/projects/',blank=True)
    projectimage3=models.ImageField(upload_to = 'static/resumeapp/img/projects/',blank=True)
    projecttitle=models.CharField(max_length=500)
    projectdescription=models.TextField(null=True)
    projectskills=models.CharField(max_length=500)
    projectlink=models.CharField(max_length=500)
    catgeory_choices=(
    ('Django Apps','Djagno Apps'),
    ('Analysis','Analysis'),
    ('Visualizations','Visualizations'),
    ('Automation','Automation'),
    ('Code Pen','Code Pen'),
    ('Python','Python')
    )
    projectcategory=models.CharField(max_length=260,choices=catgeory_choices,default='Djagno Apps')


    def __str__(self):
        return (self.projecttitle)

class IntroSection(models.Model):
    description=models.TextField(null=True)
    resume_description=models.TextField(null=True)

    def __str__(self):
        return ("Introduce your self here")

class SkillSection(models.Model):
    skillname=models.CharField(max_length=500)
    skilllevel=models.IntegerField(null=False)

    def __str__(self):
        return self.skillname

class TestimonialSection(models.Model):
    submitter=models.CharField(max_length=500)
    submitter_image=models.ImageField(upload_to = 'static/resumeapp/img/submitter/',blank=True)
    company=models.CharField(max_length=500)
    designation=models.CharField(max_length=500)
    testimonail=models.TextField(null=True)

    def __str__(self):
        return self.submitter
