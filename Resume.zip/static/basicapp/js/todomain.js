console.log("main js is working");


var myNodelist = $("ul#myUL").children();
var i;
for (i = 0; i < myNodelist.length; i++) {
  var span = document.createElement("SPAN");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  myNodelist[i].appendChild(span);
}

// Click on a close button to hide the current list item
function assignClosebutton(){
  var close = document.getElementsByClassName("close");
  var i;
  for (i = 0; i < close.length; i++) {
    close[i].onclick = function() {
      var div = this.parentElement;
      div.remove();
      $.post('/todo/deletetodo/',{'id':div.getAttribute('data-id')},function(data,success){
           console.log(data);
      });

    }
  }
}
assignClosebutton();

// Add a "checked" symbol when clicking on a list item
var list = document.getElementById("myUL");
if(list) {
  list.addEventListener('click', function(ev) {

    if (ev.target.tagName === 'LI') {
        if (ev.target.className == ''){
          $.post('/todo/checked/',{'completed_ind':1,'id':ev.target.getAttribute('data-id')},function(data,success){
                  ev.target.classList.toggle('checked');
          });
        }
        else{
          $.post('/todo/checked/',{'completed_ind':0,'id':ev.target.getAttribute('data-id')},function(data,success){
                  ev.target.classList.toggle('checked');
          });
        }
    }
  }, false);
}




// Create a new list item when clicking on the "Add" button

if($("#myInput")){

  function mynewElement() {
    var li = document.createElement("li");
    var inputValue = document.getElementById("myInput").value;
    var t = document.createTextNode(inputValue);
    li.appendChild(t);
    if (inputValue === '') {
      alert("You must write something!");
    } else {
      document.getElementById("myUL").appendChild(li);
      document.getElementById("myInput").value = "";
      var span = document.createElement("SPAN");
      var txt = document.createTextNode("\u00D7");
      span.className = "close";
      span.appendChild(txt);
      li.appendChild(span);
      assignClosebutton();
      $.post('/todo/savelist/',{'item':inputValue},function(data,success){
        var listitems=document.getElementsByTagName("li");
        for ( i=0; i< listitems.length; i++){
          listitems[i].style.display="";
          if(listitems[i].innerHTML.search(inputValue)!=-1)
          {
            listitems[i].setAttribute('data-id', data);
            }
        }


      });

    }


    }
}


// Create a new list item for others when clicking on the "Add" button
function othersnewElement(userID) {
  var li = document.createElement("li");
  var inputValue = document.getElementById("othersInput").value;
  var t = document.createTextNode(inputValue);
  li.appendChild(t);
  if (inputValue === '') {
    alert("You must write something!");
  } else {
    document.getElementById("myUL").appendChild(li);
    document.getElementById("othersInput").value = "";
    var span = document.createElement("SPAN");
    var txt = document.createTextNode("\u00D7");
    span.className = "close";
    span.appendChild(txt);
    li.appendChild(span);
    assignClosebutton();
    $.post('/todo/saveotherslist/',{'item':inputValue,'user_id':userID},function(data,success){
      console.log(data+" is added");
      var listitems=document.getElementsByTagName("li");
      for ( i=0; i< listitems.length; i++){
        listitems[i].style.display="";
        if(listitems[i].innerHTML.search(inputValue)!=-1)
        {
          listitems[i].setAttribute('data-id', data);
          }
      }


    });

  }

}

// JS for seaching user

function searchuser() {
  // Declare variables
  var input, filter, div, anc, a, i;
  input = document.getElementById("mySearch");
  filter = input.value.toUpperCase();
  div = document.getElementById("list");
  anc= div.getElementsByTagName("a");

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < anc.length; i++) {
    a = anc[i].getElementsByTagName("div")[1];
    if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
      anc[i].style.display = "";
    } else {
      anc[i].style.display = "none";
    }
  }
}


$(".search__clear").click(function(){
  // Declare variables
  var input, filter, div, anc, a, i;
  input = document.getElementById("mySearch");
  input.value="";
  filter = input.value.toUpperCase();
  div = document.getElementById("list");
  anc= div.getElementsByTagName("a");

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < anc.length; i++) {
    anc[i].style.display = "";
  }
});



// JS for seaching todo
function searchtodo() {
  var input,filter,ul,li;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  ul=document.getElementById("myUL");
  li=ul.getElementsByTagName("li");

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    if (li[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }

}


// JS for seaching other todo
function searchOtherTodo() {
  var input,filter,ul,li;
  input = document.getElementById("othersInput");
  filter = input.value.toUpperCase();
  ul=document.getElementById("myUL");
  li=ul.getElementsByTagName("li");

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    if (li[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
