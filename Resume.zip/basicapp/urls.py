from django.urls import path
from basicapp import views
from django.contrib.auth.decorators import login_required

app_name='todo'

urlpatterns = [

path(r'home/',views.userhome,name='home'),
path(r'savelist/',views.savelist,name='savelist'),
path(r'saveotherslist/',views.saveotherslist,name='saveotherslist'),
path(r'checked/',views.checked,name='checked'),
path(r'deletetodo/',views.deletetodo,name='deletetodo'),
path(r'userlistview/',views.UserListView.as_view(),name='userlistview'),
path(r'<key>$/',views.UserDetailView.as_view(),name='userview'),
path(r'todobyme/',views.TodoByme.as_view(),name='todobyme'),

]
