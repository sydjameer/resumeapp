from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.decorators.csrf import csrf_exempt,csrf_protect
from django.views.generic import ListView,DetailView,TemplateView
from django.urls.base import reverse
from django.contrib.auth  import login,logout,authenticate
from django.forms import *
from django.db.models import Q
from django.contrib.auth.models import User
from basicapp.models import Todo
# Create your views here.

def userlogin(request):
    if request.method=='POST':
        # print(request.POST)
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(request,username=username,password=password)
        if user:
                login(request,user)
                session_user={'id':user.id,'username':user.username,'first_name':user.first_name.upper(),'last_name':user.last_name.upper(),'is_assigner':user.is_staff}
                request.session['session_user']=session_user
                itemlist=Todo.objects.using('todoapp').filter(user_id=session_user['id']).order_by('completed_ind')
                return render(request,'basicapp/index.html',{'itemlist':itemlist,'user':session_user,'loggedin':True})

        else:
            return render(request,'basicapp/login.html',{'login_error':'User does not exsist'})

    else:
        if request.session.get('session_user'):
            return redirect('/todo/home/')
            exit(0)
        else:
            return render(request,'basicapp/login.html',{'loggedin':False})

@login_required
def userhome(request):
    session_user=request.session.get('session_user')
    itemlist=Todo.objects.using('todoapp').filter(user_id=session_user['id']).order_by('completed_ind')
    return render(request,'basicapp/index.html',{'itemlist':itemlist,'user':session_user,'loggedin':True})

def userlogout(request):
    logout(request)
    return redirect('/login/')


@csrf_exempt
def savelist(request):
    if request.method=='POST':
        session_user=request.session['session_user']
        newitem=Todo(user_id=session_user['id'],item=request.POST['item'],created_by=session_user['id'])
        newitem.save(using='todoapp')
        todo=Todo.objects.using('todoapp').get(item=request.POST['item'],user_id=session_user['id'])

    return JsonResponse(todo.id,safe=False)


@csrf_exempt
def saveotherslist(request):
    if request.method=='POST':
        session_user=request.session['session_user']
        newitem=Todo(user_id=request.POST['user_id'],item=request.POST['item'],created_by=session_user['id'])
        newitem.save(using='todoapp')
        todo=Todo.objects.using('todoapp').get(item=request.POST['item'],user_id=request.POST['user_id'])

    return JsonResponse(todo.id,safe=False)



@csrf_exempt
def checked(request):
    if request.method=='POST':
        # print(request.POST['completed_ind'])
        # print(request.POST['id'])
        if(int(request.POST['completed_ind'])==1):
            Todo.objects.using('todoapp').filter(id=request.POST['id']).update(completed_ind=True)
            # print("updated as true")
        else:
            Todo.objects.using('todoapp').filter(id=request.POST['id']).update(completed_ind=False)


    return JsonResponse(request.POST['id'],safe=False)


@csrf_exempt
def deletetodo(request):
    todoDelete=Todo.objects.using('todoapp').get(id=request.POST['id'])
    todoDelete.delete(using='todoapp')
    return JsonResponse(todoDelete.item+'is deleted',safe=False)


# @method_decorator(login_required(login_url='/login/'), name='dispatch')
class UserListView(ListView):
    context_object_name='todo_user'
    template_name='basicapp/user_list.html'


    def get_queryset(self):
        session_user=self.request.session['session_user']
        user_list=User.objects.exclude(id=session_user['id']).exclude(id=1)
        userDetails=[]
        for user in user_list:
            user_info={}
            todoItems=Todo.objects.using('todoapp').filter(user_id=user.id)
            user_info['username']=user.username
            user_info['first_name']=user.first_name
            user_info['last_name']=user.last_name
            user_info['count']=todoItems.count()
            user_info['user_id']=user.id
            userDetails.append(user_info)
        return userDetails

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet
        context['user']=self.request.session['session_user']
        context['loggedin']=True
        # print(context)
        return context


class UserDetailView(ListView):
    context_object_name='taskdetails'
    template_name='basicapp/user_detail.html'

    def get_queryset(self):
        # user_todos=Todo.objects.filter(user_id=self.kwargs['key'])
        session_user=self.request.session['session_user']
        user_info=User.objects.get(id=self.kwargs['key'])
        elementsList=Todo.objects.using('todoapp').filter(user_id=self.kwargs['key']).order_by('completed_ind')
        user_todos=[]
        for element in elementsList:
            todo_info={}
            todo_info['id']=element.id
            todo_info['item']=element.item
            todo_info['completed_ind']=element.completed_ind
            todo_info['created_by']=User.objects.get(id=element.created_by)
            user_todos.append(todo_info)
        return [user_todos,user_info]

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet
        context['user']=self.request.session['session_user']
        context['loggedin']=True
        # print(context)
        return context

class TodoByme(ListView):
    context_object_name='assigned'
    template_name='basicapp/byme.html'

    def get_queryset(self):
        session_user=self.request.session['session_user']
        elementsList=Todo.objects.using('todoapp').filter(created_by=session_user['id']).exclude(user_id=session_user['id'])
        userDetails=[]
        for element in elementsList:
            todo_info={}
            todo_info['item']=element.item
            todo_info['completed_ind']=element.completed_ind
            todo_info['for_user']=User.objects.get(id=element.user_id)
            userDetails.append(todo_info)

        return userDetails

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        # Add in a QuerySet
        context['user']=self.request.session['session_user']
        context['loggedin']=True
        # print(context)
        return context
